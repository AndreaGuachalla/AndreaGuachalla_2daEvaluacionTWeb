<template>
  <!-- Barra de navegación superior -->
  <nav class="navbar">
    <h1>Star Wars Characters</h1> <!-- Título principal de la aplicación -->
  </nav>
</template>

<script>
export default {
  // Definición del componente Navbar
  name: 'Navbar'
};
</script>

<style scoped>
/* Estilos específicos del componente Navbar */
.navbar {
  background-color: black; /* Fondo negro */
  color: yellow;           /* Texto en color amarillo para dar estilo temático */
  padding: 1rem;           /* Espaciado interno */
  text-align: center;      /* Centra el contenido dentro de la barra */
}
</style>
