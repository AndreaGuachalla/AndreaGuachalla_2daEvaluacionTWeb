<template>
  <div class="card">
    <!-- Muestra el nombre de la persona -->
    <h2>{{ person.name }}</h2>

    <!-- Muestra la altura de la persona en centímetros -->
    <p><strong>Altura:</strong> {{ person.height }} cm</p>

    <!-- Muestra el género de la persona -->
    <p><strong>Género:</strong> {{ person.gender }}</p>

    <!-- Muestra el año de nacimiento de la persona -->
    <p><strong>Año de nacimiento:</strong> {{ person.birth_year }}</p>
  </div>
</template>

<script>
export default {
  name: 'PersonCard', // Nombre del componente

  // Define las propiedades (props) que el componente espera recibir
  props: {
    // Se espera una prop llamada "person", que debe ser un objeto
    person: {
      type: Object,
      required: true // Esta propiedad es obligatoria
    }
  }
};
</script>

<style scoped>
/* Estilos para el componente PersonCard, limitados a este componente gracias a "scoped" */
.card {
  background-color: rgb(186, 121, 23); /* Color de fondo estilo temático */
  border-radius: 8px; /* Bordes redondeados */
  padding: 1rem; /* Espaciado interno */
  margin: 1rem; /* Espaciado externo */
  width: 350px; /* Ancho fijo */
  box-shadow: 0 2px 5px rgba(0,0,0,0.2); /* Sombra sutil para dar profundidad */
  text-align: left; /* Alineación del texto a la izquierda */
  color: #fff; /* Color del texto */
  font-family: 'Orbitron', sans-serif; /* Fuente futurista */
}

.card h2 {
  margin-top: 0; /* Elimina el margen superior del título */
  color: rgb(255, 237, 73); /* Color amarillo inspirado en Star Wars */
}
</style>
