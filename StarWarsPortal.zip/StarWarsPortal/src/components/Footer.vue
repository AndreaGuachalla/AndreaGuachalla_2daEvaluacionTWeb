<template>
  <!-- Pie de página con estilo personalizado -->
  <footer class="footer">
    <p>&copy; 2025 Star Wars Fan Portal</p> <!-- Texto con derechos de autor -->
  </footer>
</template>

<script>
export default {
  // Definición del componente Footer
  name: 'Footer'
};
</script>

<style scoped>
/* Estilos específicos para el componente Footer */
.footer {
  background-color: #1a1a1a; /* Fondo oscuro */
  color: white;              /* Texto blanco */
  text-align: center;        /* Centra el texto horizontalmente */
  padding: 1rem;             /* Espaciado interno */
  margin-top: 2rem;          /* Margen superior para separar del contenido anterior */
}
</style>
