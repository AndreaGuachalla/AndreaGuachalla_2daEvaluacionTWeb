<template>
  <div>
    <!-- Barra de navegación superior -->
    

    <!-- Buscador de personajes -->
    <div class="search-container">
      <input 
        type="text" 
        v-model="searchQuery" 
        placeholder="Buscar personaje..." 
        class="search-input"
      />
    </div>

    <!-- Estado de carga o error -->
    <div v-if="loading">Cargando personajes...</div>
    <div v-else-if="error">Ocurrió un error al obtener los datos.</div>

    <!-- Galería de tarjetas de personajes -->
    <div class="grid">
      <PersonCard 
        v-for="(person, index) in filteredPeople" 
        :key="index" 
        :person="person" 
      />
    </div>

    <!-- Controles de paginación -->
    <div style="text-align:center; margin-top: 1rem;">
      <button @click="goToPage(prevPage)" :disabled="!prevPage">Anterior</button>
      <button @click="goToPage(nextPage)" :disabled="!nextPage">Siguiente</button>
    </div>

    <!-- Pie de página -->
    
  </div>
</template>


<script>
import Navbar from '../components/Navbar.vue'
import Footer from '../components/Footer.vue'
import PersonCard from '../components/PersonCard.vue'

export default {
  name: 'PeopleList',
  components: { Navbar, Footer, PersonCard },
  data() {
    return {
      people: [],
      searchQuery: '',
      loading: true,
      error: false,
      nextPage: null,
      prevPage: null,
      currentUrl: 'https://swapi.py4e.com/api/people/'
    }
  },
  computed: {
    filteredPeople() {
      return this.people.filter(person =>
        person.name.toLowerCase().includes(this.searchQuery.toLowerCase())
      );
    }
  },
  methods: {
    fetchPeople(url) {
      this.loading = true;
      fetch(url)
        .then(res => res.json())
        .then(data => {
          this.people = data.results;
          this.nextPage = data.next;
          this.prevPage = data.previous;
          this.loading = false;
        })
        .catch(error => {
          console.error('Error al obtener los personajes:', error);
          this.error = true;
          this.loading = false;
        });
    },
    goToPage(url) {
      if (url) {
        this.currentUrl = url;
        this.fetchPeople(url);
      }
    }
  },
  mounted() {
    this.fetchPeople(this.currentUrl);
  }
}
</script>

<style scoped>
.search-container {
  display: flex;
  justify-content: center;
  margin: 1.5rem 0;
}

.search-input {
  width: 500px;
  padding: 0.5rem;
  border: 2px solid #ffe81f;              /* Borde amarillo tipo Star Wars */
  border-radius: 8px;
  font-size: 1rem;
  background-color: rgb(14, 16, 40);      /* Fondo oscuro futurista */
  color: #fff;                            /* Texto blanco */
  font-family: 'Orbitron', sans-serif;   /* Fuente sci-fi */
}

</style>
