// Importa la función para crear una aplicación Vue
import { createApp } from 'vue';

// Importa el componente raíz de la aplicación
import App from './App.vue';

// Importa la configuración del enrutador (vue-router)
import router from './router';

// Importa los estilos globales
import './style.css';

// Crea una instancia de la aplicación Vue,
// le aplica el router para el manejo de rutas,
// y la monta en el elemento con id="app" del HTML
createApp(App)
  .use(router)     // Usa el enrutador definido en './router'
  .mount('#app');  // Monta la app en el div con id="app"
