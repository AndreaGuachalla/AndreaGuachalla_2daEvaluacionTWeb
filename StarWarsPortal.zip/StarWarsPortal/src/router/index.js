// Importa funciones necesarias de Vue Router
import { createRouter, createWebHistory } from 'vue-router';

// Importa el componente que se mostrará en la ruta principal
import PeopleList from '../views/PeopleList.vue';

// Define las rutas de la aplicación
const routes = [
  {
    path: '/',                // Ruta principal (home)
    name: 'Home',             // Nombre interno de la ruta
    component: PeopleList     // Componente que se renderiza cuando se accede a esta ruta
  }
];

// Crea una instancia del router con historial del navegador (modo HTML5)
const router = createRouter({
  history: createWebHistory(), // Usa historial web en lugar de hash
  routes                       // Conjunto de rutas definidas anteriormente
});

// Exporta la instancia del router para usarla en la aplicación principal
export default router;
